@extends('layouts.app')

  <!-- <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css"> -->

  <link href="{{asset('plugins/bootstrap/bootstrap.min.css')}}" rel="stylesheet" type="text/css">
  <link href="{{asset('css/custom.css')}}" rel="stylesheet" type="text/css">
  
  <script src="{{asset('plugins/jquery/jquery.min.js')}}" type="text/javascript"></script>
  <script src="{{asset('plugins/popper/popper.min.js')}}" type="text/javascript"></script>
  <script src="{{asset('plugins/bootstrap/bootstrap.min.js')}}" type="text/javascript"></script>
  <script src="{{asset('plugins/chart/stock/highstock.js')}}" type="text/javascript"></script>
  <script src="{{asset('plugins/chart/stock/modules/exporting.js')}}" type="text/javascript"></script>

  <!-- <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js" type="text/javascript"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" type="text/javascript"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" type="text/javascript"></script>
  <script src="https://code.highcharts.com/stock/highstock.js"></script>
  <script src="https://code.highcharts.com/stock/modules/exporting.js"></script> -->
  <!-- <script src="https://code.highcharts.com/highcharts.js" type="text/javascript"></script> -->
  <!-- <script src="https://unpkg.com/react@15.3.2/dist/react.js" type="text/javascript"></script>
  <script src="https://unpkg.com/react-dom@15.3.2/dist/react-dom.js" type="text/javascript"></script>
  <script src="https://unpkg.com/babel-core@5.8.38/browser.min.js" type="text/javascript"></script>
  <script src="{{ asset('js/simplebar.js') }}" type="text/javascript"></script> -->
  <!-- <script src="{{ asset('js/chart/chart.js') }}" type="text/javascript"></script> -->
  <!-- <script src="{{asset('js/coin.js')}}" type="text/javascript"></script> -->
    @section('content')
    <div class="container">
        <!-- <table class="coin_table">
            <tr class="logo_bar">
                <td style="width: 35%">
                    <img class="logo" src="{{ asset('icons/logo.png') }}"  />
                </td>
                <td style="width: 35%">
                    <img src="" class="coin_select_img"><span class="coin_select_name"></span>
                </td>
                <td style="width: 30%">
                    <div class="dropdown">
                        <img class="hamburger dropdown-toggle" data-toggle="dropdown" src="{{ asset('icons/hamburger.png') }}"  />
                        <div class="dropdown-menu">
                            <a class="dropdown-item" href="#">Contact Us</a>
                            <a class="dropdown-item" href="#">Help</a>
                            <a class="dropdown-item" href="#">About</a>
                        </div>
                    </div>
                </td>    
            </tr>
        </table> -->
        <table width="100%">
            <thead>
                <th width="35%"></th>
                <th width="65%"></th>
            </thead>
            <tbody>
                <tr>
                    <td style="padding: 0; !important; vertical-align: top">
                        <table width='100%'>
                            <thead>
                                <tr class="nav_bar">
                                    <th class="coin_header">Coin</th>
                                    <th class="price_header">Price (7d)</th>
                                    <th class="macd_header">MACD</th>
                                </tr>
                            </thead>
                            <tbody style="height: 500px;" id="coinlists">
                                @foreach($tickers as $key => $ticker)
                                    <tr>
                                        <td class="coin">
                                            <?php $arr = explode("_", $ticker[0]); ?>
                                            <p class="coin" data-fullticker="<?php echo $ticker[0] ?>"><img src="{{ asset('icons/').'/'.$ticker[0].'.png'}}" class="coin_img" /><span class="coin_name">{{$arr[1]}}</span></p>
                                        </td>
                                        <td>
                                            
                                            <div class="price" id="<?php echo 'eachcoin'. $key ?>" style="height: 55px; width: 130px">
                                            </div>
                                           
                                        </td>
                                        <td>
                                            <div class="smacd" id="<?php echo 'eachmacd'. $key ?>" style="height: 55px; width: 60px">
                                            </div>
                                        </td>
                                    </tr>
                                @endforeach
                            </tbody>
                        </table>
                    </td>
                    <td style="padding: 0; !important; vertical-align: top; background-color: #fff;">
                        <table width='100%'>
                            <thead>
                                <tr class="nav_bar">
                                    <th >
                                    </th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td>
                                        <div class="coin_information">
                                                <img src="" class="coin_select_img"><span class="coin_select_name"></span>
                                        </div>
                                        <!-- <img src="{{ asset('icons/loadingCB.gif')}}" class="loading-gif display-hide"> -->
                                        <div id="container" style="height: 600px; min-width: 310px;" class="chart-container diplay-hide">
                                        </div>
                                        <div class="loading-gif">
                                            <!-- <img src="{{ asset('icons/loadingCB.gif')}}" class="gif"> -->
                                        </div>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </td>
                </tr>
            </tbody>
            
            
        </table>
    </div>
    @endsection
    
    @section('scripts')
    <script type="text/babel">
        //var simple = new SimpleBar(document.getElementById('coinlists'));
    </script>
    

    <script type="text/javascript">

        function getProfit(firstChartDate, profitData) {
            for(i=0;i<profitData.length;i++) {
                if(profitData[i]) {

                }
            }
        }

        $(document).ready(function() {

            <?php
            foreach($tickers as $key => $ticker) :
                $each_chart = 'eachcoin'. $key;
                $each_macd = 'eachmacd'. $key;
                $arr = explode("_", $ticker[0]);
            ?>
                tickername = "<?php echo ($arr[1]) ?>";
                testdata = "<?php echo ($ticker[1]) ?>"; //json data ['timestamps', 'open', 'high', 'low', 'close', 'macd']
                colour = <?php echo ($ticker[2]) ?>;     //colours ['colour', 'midColour,'midLight', 'lightColour']
                data = JSON.parse(testdata);
                close = []; //close data
                smacd = []; //smacd data
                // console.log('start');
                // for(i = 0; i < data.length ; i++) {
                //     close.push(data[i][4]);
                //     // console.log(data[i][5] - 1);
                // }
                c = 0;
                closec = 0;
                max = 0;
                lastdateseconds = data[data.length-1][0];
                var lastdate = new Date(lastdateseconds * 1000);
                lastdate.setDate(lastdate.getDate() - 7);
                day7ago = lastdate.getTime()/1000;
                lastdata = [];
                for( i = data.length -1 ; i>=0; i--) {
                    /**
                    if((typeof(data[i][4])!= 'undefined') && (data[i][0] >= day7ago))
                        close.push(data[i][4]);
                    */
                    if(typeof(data[i][1])!= 'undefined' && ( (closec ++) < 50)) {
                        close.push(data[i][1]); //edit
                        // closec ++;
                    }
                    if(typeof(data[i][2])!= 'undefined' && ((c++) < 10)) {
                        multi_value = (data[i][2] - 1) * 1000000000; //edit
                        lastdata.push(multi_value);
                        max = (Math.abs(max) > Math.abs(multi_value)) ? Math.abs(max) : Math.abs(multi_value);
                    }
               }
                smacd = lastdata.reverse();

                // console.log('end');
                if (data === undefined || data.length == 0) { 
                } else {

                    /**
                      *show equity line
                     */
                    Highcharts.chart('<?php echo $each_chart ?>', {
                        chart: {
                            backgroundColor: colour[0],
                            type: 'line',
                            margin: 4,
                        },
                        exporting: {
                            enabled: false
                        },
                        title: {
                            text: null
                        },
                        tooltip: {
                            enabled: false
                        },
                        credits: {
                            enabled: false
                        },
                        xAxis: {
                            visible: false,
                            text: null,
                            gridLineWidth: 0,
                            labels: {
                            enabled: false
                            }
                        },
                        yAxis: {
                            title: {
                            text: null
                            },
                            gridLineWidth: 0,
                            text: null,
                            labels: {
                            enabled: false
                            }
                        },
                        plotOptions: {

                            series: {
                                color: '#FFFFFF',
                                lineWidth: 3,
                                linecap: 'round',
                                marker: {
                                    enabled: false,
                                    states: {
                                    hover: {
                                        enabled: false
                                    }
                                    }
                                },
                                animation: false,
                                // dataGrouping: {
                                //     forced: true,
                                //     units: [
                                //         ['week', [1]]
                                //     ]
                                // },
                            }
                        },
                        series: [{
                            data: close,
                            // dataGrouping: {
                            //     approximation: function () {
                            //         console.log(
                            //             'dataGroupInfo:',
                            //             this.dataGroupInfo,
                            //             'Raw data:',
                            //             this.options.data.slice(this.dataGroupInfo.start, this.dataGroupInfo.start + this.dataGroupInfo.length)
                            //         );
                            //         return this.dataGroupInfo.length;
                            //     },
                            //     forced: true
                            // },
                            //type: 'column',
                            showInLegend: false,
                            clip: false,
                            // pointStart: Date.UTC(lastdate.getYear(),lastdate.getMonth(),lastdate.getDate(),lastdate.getHours(),lastdate.getMinutes(),lastdate.getSeconds()),
                        }]
                    });
                    
                    /**
                      *show small macd chart
                     */
                    Highcharts.chart('<?php echo $each_macd ?>', {
                        chart: {
                            backgroundColor: colour[2],
                            type: 'column',
                            margin: 4,
                            borderColor: colour[0],
                            borderWidth: 4
                        },
                        exporting: {
                            enabled: false
                        },
                        title: {
                            text: null
                        },
                        tooltip: {
                            enabled: false
                        },
                        credits: {
                            enabled: false
                        },
                        xAxis: {
                            visible: false,
                            text: null,
                            gridLineWidth: 0,
                            labels: {
                            enabled: false
                            }
                        },
                        yAxis: {
                            title: {
                            text: null
                            },
                            gridLineWidth: 0,
                            text: null,
                            labels: {
                                enabled: false
                            },
                            max: max,
                            min: 0-max
                        },
                        plotOptions: {

                            series: {
                            color: '#FFFFFF',
                            borderWidth: 0,

                            marker: {
                                enabled: false,
                                states: {
                                hover: {
                                    enabled: false
                                }
                                }
                            },
                            animation: false
                            }
                        },
                        series: [{
                            data: smacd,
                            showInLegend: false,
                            clip: false
                        }]
                    });
        

                }
            <?php endforeach; ?>
                
            /**
             * Get Host address like http://localhost:4000 
             */
            var url = window.location.href
            var arr = url.split("/");
            var hosturl = arr[0] + "//" + arr[2];
            
            /**
             * When Select Coin
             * Show ticker and Coin logo of selected coin
             * Show Main Chart(right Side)
             */
            $(document).on('click', 'p.coin', function() {

                /*  */
                $('p.coin').each(function() {
                    $(this).removeClass('coin_select');
                });
                $(this).addClass('coin_select'); 

                /* show selected logo on the top of right side */
                $('span.coin_select_name').text($(this).data('fullticker'));
                $('p.coin_select').removeClass('display-hide');
                //console.log($(this)[0].firstChild.currentSrc);
                $('.coin_select_img').attr('src', $(this)[0].firstChild.currentSrc);
                
                /* show loading gif while chart show */
                // $('div.chart-container').html('<div id="overlay"><img src="http://localhost:4000/icons/loadingCB.gif" class="loading_circle" alt="loading" /></div>');
                $('.loading-gif').addClass('loading');
                $('.chart-container').css('opacity', 0.7);

                /* Get data from database when select coin */
                $.ajax({
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    },
                    type: "POST",
                    url: hosturl + '/getcoindata',
                    data: {
                        ticker: $(this).data('fullticker')
                    },
                    success: function (suc, status) {

                        /* */
                        // $('.loading-gif').addClass('display-hide');
                        $('.loading-gif').removeClass('loading');
                        $('.chart-container').css('opacity', 1);

                        /* after loading data, show main chart using this data */
                        coindata = JSON.parse(suc);
                        data     = JSON.parse(coindata[0])
                        colour   = JSON.parse(coindata[1]);
                        profitdata = JSON.parse(coindata[2]); // [dateOpen, dateClose, priceOpen, priceClose, profit, sold_amount]
                        
                        var ohlc = [],
                            volume = [],
                            dataLength = data.length,
                            // set the allowed units for data grouping
                            groupingUnits = [[
                                'week',                         // unit name
                                [1]                             // allowed multiples
                            ], [
                                'month',
                                [1, 2, 3, 4, 6]
                            ]],
                                
                            i = 0;
                        
                    /* filter data to show equity line */
                        /* Read the firstChartDate, firstDateOpen, firstDateClose */
                        equity = [];
                        if(profitdata.length>0) {
                            if(dataLength>0)
                                firstChartDate = data[0][0];
                            dateOpen  =  profitdata[0][0];
                            dateClose =  profitdata[0][1];
                            
                            console.log(firstChartDate);
                            console.log(dateOpen);
                            console.log(dateClose);

                            for(i=0;i<dataLength;i++) {
                                
                                stepDate = data[i][0];
                                array =[];
                                /* Calculate firstpriceOnChart */
                                if((firstChartDate < dateOpen) && (stepDate < dateOpen)) {
                                    console.log('here');
                                    array.push(stepDate * 1000);
                                    array.push(profitdata[0][2] - 1);
                                    equity.push(array);
                                }
                                else if((dateOpen < firstChartDate) && (stepDate < dateClose)) {
                                    console.log('there');
                                    array.push(stepDate);
                                    array.push(profitdata[0][3] - 1);
                                    equity.push(array);
                                }    
                            }
                        }
                        console.log(equity);
                        //return;
                        i = 0;
                        /* make ohlc(open, high, low, close) data from loaded data */
                        for (i; i < dataLength; i += 1) {
                            ohlc.push([
                                //parseInt(data[i][0]) * 1000, // the date
                                1519862400000 + i * 86400000, // the date
                                data[i][1] * 1000, // open
                                data[i][2] * 1000, // high
                                data[i][3] * 1000, // low
                                data[i][4] * 1000// close
                            ]);
                    
                            volume.push([
                                //parseInt(data[i][0]) * 1000, // the date
                                1519862400000 + i * 86400000, // the date
                                data[i][5] - 1 // the macd
                            ]);
                        }
                    
                        var coincolour = colour[0];
                        var midcolour = colour[1];
                        var midlight = colour[2];
                        var lightcolour = colour[3];
                        /* create the chart */
                        Highcharts.stockChart('container', {
                            chart: {
                                type: 'candlestick',
                                marginLeft: 40, // Keep all charts left aligned
                                spacingTop: 20,
                                spacingBottom: 20,
                                zoomType: 'x',
                                backgroundColor: midlight,
                                borderColor: coincolour,
                                borderWidth: 6
                            },
                            title: {    
                                text: null,
                            },
                            credits: {
                                enabled: false
                            },
                            legend: {
                                enabled: false
                            },
                            exporting: {
                                enabled: false
                            },
                    
                    
                            // rangeSelector: {
                            //     selected: 1
                            // },
                    
                            rangeSelector: {
                                //enabled: false, // TODO make this apply to top chart only
                                inputEnabled: true,
                                inputBoxBorderColor: coincolour,
                                buttonTheme: {
                                    fill: 'none',
                                    stroke: 'none',
                                    'stroke-width': 0,
                                    r: 8,
                                    style: {
                                    color: coincolour,
                                    fontWeight: 'bold'
                                    },
                                    states: {
                                    hover: {},
                                    select: {
                                        fill: coincolour,
                                        style: {
                                        color: 'white'
                                        }
                                    }
                                    // disabled: { ... }
                                    }
                                },
                            },
                    
                    
                            xAxis: {
                                crosshair: true,
                                // gridLineWidth: 0,
                                // text: null,
                                // plotBands: [
                                //     {},
                                // ]
                                // plotBands: [{
                                    
                                // }, ]
                            },
                            yAxis: [{
                                gridLineWidth: 0,
                                labels: {
                                    enabled: true,
                                    align: 'right',
                                    x: -3
                                },
                                // title: {
                                //     text: 'OHLC'
                                // },
                                height: '60%',
                                lineWidth: 0.5,
                                resize: {
                                    enabled: true
                                }, 
                                //max: 0.1,
                                //scale: 5
                            }, {
                                gridLineWidth: 0,
                                // backgroundColor: coincolour,
                                // borderWidth: 3,
                                // borderColor: coincolour,
                    
                                labels: {
                                    enabled: false,
                                    align: 'right',
                                    x: -3
                                },
                                // title: {
                                //     text: 'Volume'
                                // },
                                top: '65%',
                                height: '35%',
                                offset: 0,
                                lineWidth: 2
                            }],
                    
                            tooltip: {
                                enabled: false, // could enable this later for numerical display - needs to handle OHLC 
                                // positioner: function() {
                                // return {
                                //   x: this.chart.chartWidth - this.label.width, // right aligned
                                //   y: -1 // align to title
                                // };
                                //},
                                borderWidth: 0,
                                backgroundColor: 'none',
                                pointFormat: '{point.y}',
                                headerFormat: '',
                                shadow: false,
                                style: {
                                fontSize: '8px'
                                },
                                //valueDecimals: dataset.valueDecimals
                            },
                            plotOptions: {
                            candlestick: {
                                color: lightcolour, //lightcolour
                                upColor: coincolour, //colour
                                lineWidth: 0.3,
                            },
                            column: {
                                color: '#FFFFFF',
                            },
                            series: {
                                animation: {
                                //duration: 5000
                                },
                                cursor: 'pointer',
                                // events: {
                                //   click: function() {
                                //     alert('You just clicked the graph');
                                //   }
                                // }
                            }
                            },
                    
                    
                    
                            series: [{
                                type: 'candlestick',
                                name: 'AAPL',
                                data: ohlc,
                                dataGrouping: {
                                    units: groupingUnits
                                }
                            },
                            //    {
                            //     type: 'spline',
                            //     name: 'EquityLine',
                            //     data: equity,
                            //     dataGrouping: {
                            //         units: groupingUnits
                            //     }
                            // }, 
                            {
                                type: 'column',
                                name: 'Volume',
                                data: volume,
                                yAxis: 1,
                                dataGrouping: {
                                    units: groupingUnits
                                }
                            }]
                        });
                    }
                });
            });
        });
    </script>

    
    @endsection